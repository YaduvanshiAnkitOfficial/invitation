# Your editable wedding invitation

This package closely reproduces the supplied invitation at https://anushamukul.creativeconceptsgifts.in, including its ribbon and palace opening video, music, names, blessing, scratch heart, countdown, photo carousel, event cards, map links, family section and closing. The original public sample details are preserved so you can compare it first.

## 1. Open the editor

On a computer with Python 3 installed, double-click `start_preview.py`, or run `python start_preview.py` from this folder. A browser opens the visual editor. On Windows you can also double-click `START_WINDOWS.bat`.

You can also serve the folder with any ordinary static web server, then open `editor.html`. Opening the HTML directly as a `file://` document will block browser modules and ZIP export. No Node.js install, npm command, build step, API key or database is required.

## 2. Make it yours

1. Change names, parents, relation labels and monogram initials in **The couple**.
2. Set the countdown date, time and time zone in **Date & invitation**. The time includes a UTC offset. For India, use `+05:30` and `Asia/Kolkata`. Changing it also updates the scratch-heart date. Every event has its own date and time, so update those separately.
3. Upload your photos, enter your story, edit the events, venues and map links, and update family names.
4. Replace the opening video, cover image, music or artwork under **Video, music & artwork** if needed. The ribbon opening and palace are part of the MP4. Changing names changes the live text overlay. Text baked into an image or video requires editing that media file itself.
5. Set the share-preview title, description and image under **Link sharing & backups**. If you already have a public URL, enter it so image URLs can be absolute.
6. Click **Update preview**. Tap the ribbon in the phone to open. Scroll through every section. Use the Wide button to preview a larger layout.
7. Click **Download website ZIP**, then click the **Save website ZIP** link that appears. It includes the edited settings, all required local files, and your uploaded media. Extract the ZIP before using it.

Edits do not automatically change a published invitation. They are held in the current editor tab until downloaded. Reloading the editor discards unsaved edits. Exported uploads become ordinary files inside `media/`. Keep a backup ZIP.

For text-only updates you may download `config.js` and replace that file in your existing website. When replacing photos or video, use the full ZIP. Advanced users can edit `config.js` directly. `config.example.json` documents the settings structure. Import accepts a downloaded config.js or JSON without executing it.

## 3. Publish and share with guests

The supplied hosted preview, if provided, is private to your account. It is not a public guest invitation.

An easy public hosting option is Netlify Drop:

1. Open https://app.netlify.com/drop and follow its account/setup prompts as required.
2. Upload the extracted website folder containing `index.html`, `config.js`, `assets/`, `media/`, `videos/` and `src/`. `index.html` must be at the top of the uploaded site, not inside another nested folder.
3. Use the public HTTPS address returned by your host. Send that URL through WhatsApp, email or a message. Send the root invitation address, not `/editor.html`.
4. To make changes later, download the revised ZIP from your editor and upload its contents to the same hosting project. Keep the same address.

Official deployment guide: https://docs.netlify.com/start/quickstarts/netlify-drop-quickstart/

GitHub Pages is another option. Upload the website files to the publishing branch root, add an empty `.nojekyll` file, then select that branch and root folder in **Settings → Pages**. The relative paths in this package support a project subfolder.

Official GitHub guide: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

Optional: after publishing, enter your public URL in the editor and export again to create absolute image metadata for link previews. WhatsApp may cache earlier preview images and text. A share-preview image should match the image dimensions specified in `index.html` (1200 × 630 by default).

## Files you should keep

| File or folder | Purpose |
| --- | --- |
| `index.html` | Invitation entry page and social preview metadata |
| `config.js` | All editable details and media paths |
| `assets/` | Application sections, local fonts, styles and bundled animation libraries |
| `media/` | Photos, illustrations, music, record image and monogram |
| `videos/` | Opening animation |
| `src/settings.js` | Connects every section to your configuration |
| `src/enhancements.js` | Keyboard access and music behaviour |
| `editor.html`, `src/editor.js`, `src/editor.css` | Optional visual editor |
| `files.json` | File list needed for editor ZIP export |
| `start_preview.py`, `START_WINDOWS.bat` | Local preview launchers; the host does not execute these |
| `THIRD_PARTY_NOTICES.md`, `SOURCE_NOTES.md` | Source attribution and asset information |

Keep all the files if you want the editor and ZIP export to keep working. You may publish only `index.html`, `config.js`, `assets/`, `media/`, `videos/`, `src/settings.js` and `src/enhancements.js` for guests. Keep your complete editor copy elsewhere. The editor is a local editing tool, not an authenticated admin console. It cannot alter server files or save changes for other visitors.

## Things to know

- This is an editable adaptation of the publicly delivered website, not the original designer's unbundled development project or private server source. Public production component names are preserved so existing styles and animations remain aligned.
- All required sample images, MP4, MP3, fonts and libraries are included locally. The invitation does not depend on the original website staying online. Google Maps links open an external service only when clicked.
- The palette controls change the main site colours. Some original gold ornaments, embedded artwork and highlight colours are fixed in their assets or styles.
- No guest data is collected. There is no RSVP database, payment flow or email service.
- Browser autoplay rules require a guest interaction for music. Music can be paused using the record button. Device silent mode, browser preferences and loading speed may affect playback.
- The scratch heart works with mouse or touch. Keyboard users can focus it and press Enter or Space to reveal the date.
- Exact appearance and timing vary with screen size, browser, video rendering and font rasterization. The reference layout and media have been retained, with a separate editor and keyboard enhancements added.
- Use your own photographs and music, or obtain permission for the supplied reference assets before public reuse. Including them here does not grant rights to the original creator's work.
