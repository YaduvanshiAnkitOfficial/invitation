import {
  invitation as W
} from "../src/settings.js";
import {
  n as e
} from "./rolldown-runtime-Bh1tDfsg.js";
import {
  c as t,
  o as n
} from "./react-CC4f5wG5.js";
import {
  r
} from "./gsap-BL2wBkID.js";
var i = e(t(), 1),
  a = {
    storySection: `_storySection_35koi_1`,
    container: `_container_35koi_9`,
    imageCol: `_imageCol_35koi_17`,
    carouselContainer: `_carouselContainer_35koi_23`,
    imageWrapper: `_imageWrapper_35koi_35`,
    image: `_image_35koi_17`,
    textCol: `_textCol_35koi_76`,
    title: `_title_35koi_83`,
    paragraph: `_paragraph_35koi_91`
  },
  o = n(),
  s = W.gallery,
  c = () => {
    let e = (0, i.useRef)(null),
      t = (0, i.useRef)(null),
      n = (0, i.useRef)(null),
      c = (0, i.useRef)([]),
      [l, u] = (0, i.useState)(0),
      [d, f] = (0, i.useState)(!1),
      p = (0, i.useRef)(null),
      m = (0, i.useRef)(null),
      h = (0, i.useRef)(!1),
      g = (0, i.useRef)(!1),
      _ = (0, i.useRef)(0);
    (0, i.useEffect)(() => {
      s.forEach(e => {
        let t = new Image;
        t.src = e
      })
    }, []), (0, i.useEffect)(() => {
      let t = e.current,
        n = new IntersectionObserver(([e]) => f(e.isIntersecting), {
          threshold: .2
        });
      return t && n.observe(t), () => t && n.unobserve(t)
    }, []);
    let v = (0, i.useCallback)(() => {
        u(e => (e + 1) % s.length)
      }, []),
      y = (0, i.useCallback)(() => {
        u(e => (e - 1 + s.length) % s.length)
      }, []),
      b = (0, i.useCallback)(() => {
        p.current && clearTimeout(p.current), m.current && clearInterval(m.current), h.current ? m.current = setInterval(v, 3500) : p.current = setTimeout(() => {
          v(), h.current = !0, m.current = setInterval(v, 3500)
        }, 1e3)
      }, [v]),
      x = (0, i.useCallback)(() => {
        p.current && clearTimeout(p.current), m.current && clearInterval(m.current)
      }, []);
    return (0, i.useEffect)(() => (d ? b() : x(), x), [d, b, x]), (0, i.useEffect)(() => {
      c.current.forEach((e, t) => {
        if (!e) return;
        let n = window.innerWidth <= 900 ? 60 : 120,
          i = t - l;
        i > 1 && (i -= s.length), i < -1 && (i += s.length);
        let a, o, c, u;
        i === 0 ? (a = 0, o = 1, c = 1, u = 3) : i === 1 ? (a = n, o = .85, c = .5, u = 2) : i === -1 ? (a = -n, o = .85, c = .5, u = 2) : (a = 0, o = .5, c = 0, u = 1), r.to(e, {
          x: a,
          scale: o,
          opacity: c,
          zIndex: u,
          duration: .6,
          ease: `power3.out`,
          overwrite: `auto`
        })
      })
    }, [l]), (0, i.useEffect)(() => {
      let i = r.context(() => {
        r.fromTo(n.current, {
          opacity: 0,
          x: -50
        }, {
          opacity: 1,
          x: 0,
          duration: 1.2,
          ease: `power2.out`,
          scrollTrigger: {
            trigger: e.current,
            start: `top 70%`
          }
        }), r.fromTo(t.current.children, {
          opacity: 0,
          y: 30
        }, {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: .2,
          ease: `power2.out`,
          scrollTrigger: {
            trigger: e.current,
            start: `top 70%`
          }
        })
      }, e);
      return () => i.revert()
    }, []), (0, o.jsx)(`section`, {
      className: a.storySection,
      ref: e,
      children: (0, o.jsxs)(`div`, {
        className: a.container,
        children: [(0, o.jsx)(`div`, {
          className: a.imageCol,
          children: (0, o.jsx)(`div`, {
            className: a.carouselContainer,
            ref: n,
            onPointerDown: e => {
              g.current = !0, _.current = e.clientX, x()
            },
            onPointerUp: e => {
              if (!g.current) return;
              let t = e.clientX,
                n = _.current - t;
              Math.abs(n) > 50 && (n > 0 ? v() : y()), g.current = !1, b()
            },
            onPointerLeave: () => {
              g.current && (g.current = !1, b())
            },
            children: s.map((e, t) => (0, o.jsx)(`div`, {
              ref: e => c.current[t] = e,
              className: a.imageWrapper,
              children: (0, o.jsx)(`img`, {
                src: e,
                alt: W.bride + " and " + W.groom,
                className: a.image,
                loading: t === 0 ? `eager` : `lazy`,
                draggable: `false`
              })
            }, t))
          })
        }), (0, o.jsxs)(`div`, {
          className: a.textCol,
          ref: t,
          children: [(0, o.jsx)(`h2`, {
            className: a.title,
            children: W.storyTitle
          }), (0, o.jsx)(`p`, {
            className: a.paragraph,
            children: W.storyParagraphs[0]
          }), (0, o.jsx)(`p`, {
            className: a.paragraph,
            children: W.storyParagraphs[1]
          }), (0, o.jsx)(`p`, {
            className: a.paragraph,
            children: W.storyParagraphs[2]
          }), (0, o.jsx)(`p`, {
            className: a.paragraph,
            children: W.storyParagraphs[3]
          })]
        })]
      })
    })
  };
export {
  c as
  default
};
