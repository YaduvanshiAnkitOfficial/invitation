import {
  invitation as W
} from "../src/settings.js";
const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/Couple-DECLg_VI.js", "assets/rolldown-runtime-Bh1tDfsg.js", "assets/react-CC4f5wG5.js", "assets/gsap-BL2wBkID.js", "assets/Couple-CNROOB51.css", "assets/ScratchCard-5WFea2BG.js", "assets/ScratchCard-CXUnNtGo.css", "assets/Countdown-XVXzEh21.js", "assets/Countdown-Bl1W6mZx.css", "assets/Story-gallery-v4.js", "assets/Story-DsehGPmT.css", "assets/Timeline-maps-v6.js", "assets/Timeline-o6upnVhj.css", "assets/FamilyDetails-G_C-lIDT.js", "assets/FamilyDetails-DHdpaFvs.css", "assets/rolldown-runtime-Bh1tDfsg.js", "assets/index-DhLyTM3w.css", "assets/Footer-BM1WRL84.js", "assets/Footer-npvlNF2J.css"]))) => i.map(i => d[i]);
import {
  n as e
} from "./rolldown-runtime-Bh1tDfsg.js";
import {
  c as t,
  o as n,
  s as r
} from "./react-CC4f5wG5.js";
import {
  t as i
} from "./lenis-Co0czXzS.js";
import {
  n as a,
  r as o
} from "./gsap-BL2wBkID.js";
(function() {
  let e = document.createElement(`link`).relList;
  if (e && e.supports && e.supports(`modulepreload`)) return;
  for (let e of document.querySelectorAll(`link[rel="modulepreload"]`)) n(e);
  new MutationObserver(e => {
    for (let t of e)
      if (t.type === `childList`)
        for (let e of t.addedNodes) e.tagName === `LINK` && e.rel === `modulepreload` && n(e)
  }).observe(document, {
    childList: !0,
    subtree: !0
  });

  function t(e) {
    let t = {};
    return e.integrity && (t.integrity = e.integrity), e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy), e.crossOrigin === `use-credentials` ? t.credentials = `include` : e.crossOrigin === `anonymous` ? t.credentials = `omit` : t.credentials = `same-origin`, t
  }

  function n(e) {
    if (e.ep) return;
    e.ep = !0;
    let n = t(e);
    fetch(e.href, n)
  }
})();
var s = e(t(), 1),
  c = r(),
  l = {
    player: `_player_1m9ai_5`,
    glow: `_glow_1m9ai_1`,
    record: `_record_1m9ai_43`,
    disc: `_disc_1m9ai_55`
  },
  u = n(),
  d = (0, s.memo)(function({
    opened: e
  }) {
    let t = (0, s.useRef)(null),
      n = (0, s.useRef)(null),
      r = (0, s.useRef)(null),
      i = (0, s.useRef)(null),
      a = (0, s.useRef)(null);
    return (0, s.useEffect)(() => {
      let e = o.to(r.current, {
        rotation: 360,
        duration: 8,
        ease: `none`,
        repeat: -1,
        paused: !0
      });
      i.current = e, o.set(n.current, {
        opacity: 0,
        y: 60
      });
      let t = a.current;
      return () => {
        e.kill(), t && t.kill()
      }
    }, []), (0, s.useEffect)(() => {
      if (!e) return;
      o.to(n.current, {
        opacity: 1,
        y: 0,
        duration: .8,
        ease: `power2.out`
      });
      let r = t.current;
      if (window.__invitationAudioStarted) {
        i.current.play();
        return
      }
      r.muted = false, r.volume = .5, r.play().then(() => {
        o.to(r, {
          volume: .5,
          duration: 2
        }), i.current.play()
      }).catch(() => {})
    }, [e]), (0, u.jsxs)(u.Fragment, {
      children: [(0, u.jsx)(`audio`, {
        ref: t,
        src: W.media.music,
        loop: !0
      }), (0, u.jsx)(`button`, {
        ref: n,
        className: l.player,
        onClick: () => {
          let e = t.current;
          e.muted = false;
          e.volume = .5;
          if (e.paused) {
            e.play().then(() => {
              window.__invitationAudioStarted = true;
              i.current.play();
            }).catch(error => {
              console.warn("Music playback could not start. Check the audio path and browser media settings.", error);
            });
          } else {
            e.pause();
            i.current.pause();
          }
        },
        children: (0, u.jsx)(`img`, {
          ref: r,
          src: W.media.record,
          alt: `Music`,
          loading: `lazy`,
          className: l.record
        })
      })]
    })
  }),
  f = {
    preloaderContainer: `_preloaderContainer_icvh7_1`,
    hidden: `_hidden_icvh7_17`,
    contentWrapper: `_contentWrapper_icvh7_22`,
    fadeIn: `_fadeIn_icvh7_1`,
    logo: `_logo_icvh7_32`,
    float: `_float_icvh7_1`,
    loadingText: `_loadingText_icvh7_41`,
    pulseText: `_pulseText_icvh7_1`,
    loaderLine: `_loaderLine_icvh7_53`,
    shimmerLine: `_shimmerLine_icvh7_1`,
    particles: `_particles_icvh7_74`,
    particle: `_particle_icvh7_74`,
    floatParticle: `_floatParticle_icvh7_1`
  },
  p = ({
    onComplete: e,
    videoReady: t
  }) => {
    let [n, r] = (0, s.useState)(!1), i = (0, s.useMemo)(() => Array.from({
      length: 25
    }).map((e, t) => ({
      id: t,
      left: `${Math.random()*100}%`,
      animationDuration: `${Math.random()*5+5}s`,
      animationDelay: `${Math.random()*5}s`,
      width: `${Math.random()*4+2}px`,
      height: `${Math.random()*4+2}px`
    })), []);
    return (0, s.useEffect)(() => {
      if (t) {
        r(!0);
        let t = setTimeout(() => {
          e && e()
        }, 600);
        return () => clearTimeout(t)
      }
    }, [t, e]), (0, u.jsxs)(`div`, {
      className: `${f.preloaderContainer} ${n?f.hidden:``}`,
      children: [(0, u.jsx)(`div`, {
        className: f.particles,
        children: i.map(e => (0, u.jsx)(`div`, {
          className: f.particle,
          style: {
            left: e.left,
            width: e.width,
            height: e.height,
            animationDuration: e.animationDuration,
            animationDelay: e.animationDelay
          }
        }, e.id))
      }), (0, u.jsxs)(`div`, {
        className: f.contentWrapper,
        children: [(0, u.jsx)(`img`, {
          src: W.monogram,
          alt: W.bride + " and " + W.groom + " monogram",
          className: f.logo
        }), (0, u.jsx)(`h1`, {
          className: f.loadingText,
          children: W.loadingText
        }), (0, u.jsx)(`div`, {
          className: f.loaderLine
        })]
      })]
    })
  },
  m = {
    hero: `_hero_11gmz_1`,
    videoBackground: `_videoBackground_11gmz_12`,
    posterImage: `_posterImage_11gmz_22`,
    posterHidden: `_posterHidden_11gmz_34`,
    overlay: `_overlay_11gmz_38`,
    tapButton: `_tapButton_11gmz_52`,
    tapText: `_tapText_11gmz_70`,
    breathingText: `_breathingText_11gmz_1`,
    tapIcon: `_tapIcon_11gmz_80`,
    breathingLogo: `_breathingLogo_11gmz_1`,
    namesWrapper: `_namesWrapper_11gmz_88`,
    namesPositioner: `_namesPositioner_11gmz_101`,
    namesContainer: `_namesContainer_11gmz_110`,
    name: `_name_11gmz_88`,
    weds: `_weds_11gmz_142`,
    scrollIndicator: `_scrollIndicator_11gmz_156`,
    scrollIndicatorContent: `_scrollIndicatorContent_11gmz_166`,
    hapticBounce: `_hapticBounce_11gmz_1`,
    scrollText: `_scrollText_11gmz_188`,
    scrollArrow: `_scrollArrow_11gmz_202`,
    musicPlayerWrapper: `_musicPlayerWrapper_11gmz_214`,
    loaderWrapper: `_loaderWrapper_11gmz_262`,
    loaderLogo: `_loaderLogo_11gmz_270`,
    float: `_float_11gmz_1`,
    premiumLoader: `_premiumLoader_11gmz_283`,
    spinPremium: `_spinPremium_11gmz_1`,
    spinPremiumReverse: `_spinPremiumReverse_11gmz_1`,
    loaderText: `_loaderText_11gmz_320`,
    pulse: `_pulse_11gmz_1`
  },
  h = ({
    onOpen: e,
    onAnimationComplete: t,
    onVideoReady: n
  }) => {
    let [r, i] = (0, s.useState)(!1), [a, c] = (0, s.useState)(!1), [l, d] = (0, s.useState)(!1), f = (0, s.useRef)(null), p = (0, s.useRef)(null), h = (0, s.useRef)(null), g = (0, s.useRef)(null), _ = (0, s.useRef)(!1);
    return (0, s.useEffect)(() => {
      let e = f.current;
      if (!e) return;
      let t = !1,
        r = !1,
        i = !1;
      console.log(`Preloader started`), console.log(`Video request started`);
      let a = e => {
          t || (t = !0, console.log(`Hero shown (${e})`), setTimeout(() => {
            n && n()
          }, 50))
        },
        o = () => {
          console.log(`Metadata loaded`), r && d(!0)
        },
        s = () => {
          console.log(`First frame available`), d(!0), r || a(`loadeddata event`)
        },
        c = () => {
          i || (i = !0, console.log(`Video playing`), d(!0))
        };
      e.addEventListener(`loadedmetadata`, o), e.addEventListener(`loadeddata`, s), e.addEventListener(`playing`, c);
      let l = setTimeout(() => {
        t || (r = !0, console.log(`Timeout reached`), a(`timeout`))
      }, 4500);
      return e.readyState >= 2 && s(), () => {
        clearTimeout(l), e.removeEventListener(`loadedmetadata`, o), e.removeEventListener(`loadeddata`, s), e.removeEventListener(`playing`, c)
      }
    }, [n]), (0, s.useEffect)(() => {
      if (a) {
        let e = o.context(() => {
          o.timeline().fromTo(h.current.children, {
            opacity: 0,
            y: 40,
            scale: .9,
            clipPath: `polygon(-50% 150%, 150% 150%, 150% 150%, -50% 150%)`
          }, {
            opacity: 1,
            y: 0,
            scale: 1,
            clipPath: `polygon(-50% -50%, 150% -50%, 150% 150%, -50% 150%)`,
            duration: 1.5,
            stagger: .4,
            ease: `power3.out`,
            clearProps: `clipPath`
          }).fromTo(g.current, {
            opacity: 0,
            y: 20
          }, {
            opacity: 1,
            y: 0,
            duration: .6,
            ease: `power2.out`,
            onComplete: () => {
              t && t()
            }
          }, `+=1`)
        });
        return () => {
          e.revert()
        }
      }
    }, [a, t]), (0, u.jsxs)(`section`, {
      className: m.hero,
      onClick: r ? void 0 : () => {
        _.current || (_.current = !0, i(!0), e && e(), setTimeout(() => {
          c(!0)
        }, 6e3), f.current ? (() => {
          let e = f.current.play();
          e !== void 0 && e.catch(e => {
            console.warn(`Video play prevented:`, e), c(!0)
          })
        })() : c(!0), o.to(p.current, {
          opacity: 0,
          duration: 1,
          ease: `power2.out`,
          onComplete: () => {
            p.current && (p.current.style.display = `none`)
          }
        }))
      },
      children: [(0, u.jsx)(`video`, {
        ref: f,
        className: m.videoBackground,
        src: W.media.heroVideo,
        muted: !0,
        playsInline: !0,
        preload: `auto`,
        fetchPriority: `high`,
        poster: W.media.poster,
        onTimeUpdate: () => {
          !f.current || a || !r || f.current.currentTime >= 5 && c(!0)
        }
      }), (0, u.jsx)(`img`, {
        src: W.media.poster,
        alt: `Hero Poster`,
        className: `${m.posterImage} ${l?m.posterHidden:``}`
      }), (0, u.jsx)(`div`, {
        ref: p,
        className: m.overlay,
        children: (0, u.jsxs)(`div`, {
          className: m.tapButton,
          children: [(0, u.jsx)(`span`, {
            className: m.tapText,
            children: W.tapText
          }), (0, u.jsx)(`div`, {
            className: m.tapIcon,
            children: (0, u.jsx)(`img`, {
              src: W.monogram,
              alt: W.bride + " and " + W.groom + " monogram",
              style: {
                width: `100%`,
                height: `100%`,
                objectFit: `contain`
              }
            })
          })]
        })
      }), (0, u.jsx)(`div`, {
        className: m.namesWrapper,
        style: {
          pointerEvents: a ? `auto` : `none`
        },
        children: (0, u.jsx)(`div`, {
          className: m.namesPositioner,
          children: (0, u.jsxs)(`div`, {
            ref: h,
            className: m.namesContainer,
            children: [(0, u.jsx)(`h2`, {
              className: m.name,
              children: W.bride
            }), (0, u.jsx)(`span`, {
              className: m.weds,
              children: W.wedsText
            }), (0, u.jsx)(`h2`, {
              className: m.name,
              children: W.groom
            })]
          })
        })
      }), (0, u.jsx)(`div`, {
        ref: g,
        className: m.scrollIndicator,
        style: {
          opacity: 0,
          pointerEvents: `none`
        },
        children: (0, u.jsxs)(`div`, {
          className: m.scrollIndicatorContent,
          children: [(0, u.jsx)(`span`, {
            className: m.scrollText,
            children: W.scrollText
          }), (0, u.jsx)(`div`, {
            className: m.scrollArrow,
            children: `↓`
          })]
        })
      })]
    })
  },
  g = `modulepreload`,
  _ = function(e) {
    return new URL("../" + e, import.meta.url).href
  },
  v = {},
  y = function(e, t, n) {
    let r = Promise.resolve();
    if (t && t.length > 0) {
      let e = document.getElementsByTagName(`link`),
        i = document.querySelector(`meta[property=csp-nonce]`),
        a = i?.nonce || i?.getAttribute(`nonce`);

      function o(e) {
        return Promise.all(e.map(e => Promise.resolve(e).then(e => ({
          status: `fulfilled`,
          value: e
        }), e => ({
          status: `rejected`,
          reason: e
        }))))
      }

      function s(e) {
        return import.meta.resolve ? import.meta.resolve(e) : new URL(e, import.meta.url).href
      }
      r = o(t.map(t => {
        if (t = _(t, n), t = s(t), t in v) return;
        v[t] = !0;
        let r = t.endsWith(`.css`);
        for (let n = e.length - 1; n >= 0; n--) {
          let i = e[n];
          if (i.href === t && (!r || i.rel === `stylesheet`)) return
        }
        let i = document.createElement(`link`);
        if (i.rel = r ? `stylesheet` : g, r || (i.as = `script`), i.crossOrigin = ``, i.href = t, a && i.setAttribute(`nonce`, a), document.head.appendChild(i), r) return new Promise((e, n) => {
          i.addEventListener(`load`, e), i.addEventListener(`error`, () => n(Error(`Unable to preload CSS for ${t}`)))
        })
      }))
    }

    function i(e) {
      let t = new Event(`vite:preloadError`, {
        cancelable: !0
      });
      if (t.payload = e, window.dispatchEvent(t), !t.defaultPrevented) throw e
    }
    return r.then(t => {
      for (let e of t || []) e.status === `rejected` && i(e.reason);
      return e().catch(i)
    })
  },
  b = (0, s.lazy)(() => y(() => import(`./Couple-DECLg_VI.js`), __vite__mapDeps([0, 1, 2, 3, 4]))),
  x = (0, s.lazy)(() => y(() => import(`./ScratchCard-5WFea2BG.js`), __vite__mapDeps([5, 1, 2, 3, 6]))),
  S = (0, s.lazy)(() => y(() => import(`./Countdown-XVXzEh21.js`), __vite__mapDeps([7, 1, 2, 3, 8]))),
  C = (0, s.lazy)(() => y(() => import(`./Story-gallery-v4.js`), __vite__mapDeps([9, 1, 2, 3, 10]))),
  w = (0, s.lazy)(() => y(() => import(`./Timeline-maps-v6.js`), __vite__mapDeps([11, 1, 2, 3, 12]))),
  T = (0, s.lazy)(() => y(() => import(`./FamilyDetails-G_C-lIDT.js`), __vite__mapDeps([13, 1, 2, 3, 14]))),
  D = (0, s.lazy)(() => y(() => import(`./Footer-BM1WRL84.js`), __vite__mapDeps([17, 2, 1, 18])));
o.registerPlugin(a), `scrollRestoration` in window.history && (window.history.scrollRestoration = `manual`), a.clearScrollMemory(`manual`), window.scrollTo(0, 0);

function O() {
  let [e, t] = (0, s.useState)(!1), [n, r] = (0, s.useState)(!1), [c, l] = (0, s.useState)(!1), f = (0, s.useRef)(null);
  (0, s.useEffect)(() => {
    window.scrollTo(0, 0);
    let e = new i({
      duration: 1.2,
      easing: e => Math.min(1, 1.001 - 2 ** (-10 * e)),
      orientation: `vertical`,
      gestureOrientation: `vertical`,
      smoothWheel: !0
    });
    e.stop(), f.current = e, e.on(`scroll`, a.update);
    let t = t => {
      e.raf(t * 1e3)
    };
    return o.ticker.add(t), o.ticker.lagSmoothing(0, 0), () => {
      o.ticker.remove(t), e.destroy(), f.current = null
    }
  }, []);
  let m = (0, s.useCallback)(() => {
    f.current && f.current.start()
  }, []);
  return (0, u.jsxs)(u.Fragment, {
    children: [!c && (0, u.jsx)(p, {
      videoReady: n,
      onComplete: () => l(!0)
    }), (0, u.jsxs)(`main`, {
      children: [(0, u.jsx)(h, {
        onVideoReady: () => r(!0),
        onOpen: () => t(!0),
        onAnimationComplete: m
      }), c && (0, u.jsxs)(s.Suspense, {
        fallback: (0, u.jsx)(`div`, {
          style: {
            height: `100vh`
          }
        }),
        children: [(0, u.jsx)(b, {}), (0, u.jsx)(x, {}), (0, u.jsx)(S, {}), (0, u.jsx)(C, {}), (0, u.jsx)(w, {}), (0, u.jsx)(T, {}), (0, u.jsx)(D, {})]
      }), (0, u.jsx)(d, {
        opened: e
      })]
    })]
  })
}(0, c.createRoot)(document.getElementById(`root`)).render((0, u.jsx)(s.StrictMode, {
  children: (0, u.jsx)(O, {})
}));
