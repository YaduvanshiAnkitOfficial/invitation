import {
  invitation as W
} from "../src/settings.js";
import {
  n as e
} from "./rolldown-runtime-Bh1tDfsg.js";
import {
  c as t,
  o as n
} from "./react-CC4f5wG5.js";
import {
  n as r,
  r as i
} from "./gsap-BL2wBkID.js";
var a = e(t(), 1),
  o = {
    scratchSection: `_scratchSection_ryx1z_1`,
    header: `_header_ryx1z_15`,
    headingSmall: `_headingSmall_ryx1z_21`,
    headingSub: `_headingSub_ryx1z_30`,
    container: `_container_ryx1z_39`,
    card: `_card_ryx1z_50`,
    floatingHeart: `_floatingHeart_ryx1z_1`,
    heartBorder: `_heartBorder_ryx1z_67`,
    heartBackground: `_heartBackground_ryx1z_77`,
    heartSvg: `_heartSvg_ryx1z_87`,
    revealedContent: `_revealedContent_ryx1z_93`,
    revealItem: `_revealItem_ryx1z_108`,
    dateText: `_dateText_ryx1z_115`,
    revealIcon: `_revealIcon_ryx1z_125`,
    canvasWrapper: `_canvasWrapper_ryx1z_129`,
    shimmerOverlay: `_shimmerOverlay_ryx1z_139`,
    shimmerSweep: `_shimmerSweep_ryx1z_1`,
    scratchCanvas: `_scratchCanvas_ryx1z_167`,
    breathing: `_breathing_ryx1z_1`,
    particleCanvas: `_particleCanvas_ryx1z_195`,
    ambientDecor: `_ambientDecor_ryx1z_205`,
    ambientParticle: `_ambientParticle_ryx1z_216`,
    ambientFloat: `_ambientFloat_ryx1z_1`,
    instructionWrapper: `_instructionWrapper_ryx1z_229`,
    instructionText: `_instructionText_ryx1z_239`,
    handIcon: `_handIcon_ryx1z_249`,
    swipe: `_swipe_ryx1z_1`
  },
  s = n();
i.registerPlugin(r);
var c = () => Array.from({
    length: 30
  }).map((e, t) => ({
    left: `${Math.random()*100}%`,
    animationDuration: `${15+Math.random()*20}s`,
    animationDelay: `-${Math.random()*20}s`,
    width: `${Math.random()*4+2}px`,
    height: `${Math.random()*4+2}px`,
    backgroundColor: t % 2 == 0 ? `#C9A24A` : `#FDF2A9`,
    opacity: Math.random() * .5 + .2,
    boxShadow: `0 0 4px rgba(255,255,255,0.8)`
  })),
  l = () => {
    let e = (0, a.useRef)(null),
      t = (0, a.useRef)(null),
      n = (0, a.useRef)(null),
      r = (0, a.useRef)(null),
      l = (0, a.useRef)(null),
      u = (0, a.useRef)(null),
      [d, f] = (0, a.useState)(!1),
      [p] = (0, a.useState)(c),
      m = (0, a.useRef)(!1),
      h = (0, a.useRef)(!1),
      g = (0, a.useRef)(null),
      _ = (0, a.useRef)(new Set),
      v = (0, a.useRef)(!1),
      y = (0, a.useRef)([]),
      b = (0, a.useRef)(null),
      x = (0, a.useRef)([]),
      S = e => {
        e.touches && e.touches.length > 0 && !m.current && e.preventDefault()
      };
    return (0, a.useEffect)(() => {
      let a = i.context(() => {
          i.fromTo(e.current, {
            opacity: 0,
            y: 30
          }, {
            opacity: 1,
            y: 0,
            duration: 1.2,
            ease: `power3.out`,
            scrollTrigger: {
              trigger: e.current,
              start: `top 75%`
            }
          }), i.fromTo(t.current, {
            scale: .9,
            opacity: 0
          }, {
            scale: 1,
            opacity: 1,
            duration: 1.2,
            delay: .2,
            ease: `power3.out`,
            scrollTrigger: {
              trigger: e.current,
              start: `top 75%`
            }
          })
        }),
        s = n.current,
        c = r.current;
      if (!s || !c) return;
      let d = s.getContext(`2d`, {
          willReadFrequently: !0
        }),
        p = c.getContext(`2d`),
        {
          width: C,
          height: w,
          pRect: T,
          dpr: E
        } = (() => {
          let e = s.parentElement.getBoundingClientRect().width || 350,
            n = e;
          t.current && (t.current.style.height = `${n}px`);
          let r = window.devicePixelRatio || 1;
          s.width = e * r, s.height = n * r, d.scale(r, r);
          let i = c.getBoundingClientRect();
          return c.width = i.width * r, c.height = i.height * r, p.scale(r, r), {
            width: e,
            height: n,
            pRect: i,
            dpr: r
          }
        })(),
        D = document.createElement(`canvas`);
      D.width = s.width, D.height = s.height;
      let O = D.getContext(`2d`);
      O.scale(E, E);
      let k = O.createLinearGradient(0, 0, C, w);
      k.addColorStop(0, `#D4AF37`), k.addColorStop(.3, `#E6C27A`), k.addColorStop(.5, `#C9A227`), k.addColorStop(.7, `#FDF2A9`), k.addColorStop(1, `#AA771C`), O.fillStyle = k, O.fillRect(0, 0, C, w), O.globalCompositeOperation = `source-atop`;
      for (let e = 0; e < C * w * .05; e++) O.fillStyle = Math.random() > .5 ? `rgba(255,255,255,0.03)` : `rgba(0,0,0,0.03)`, O.fillRect(Math.random() * C, Math.random() * w, 1, 1);
      O.globalCompositeOperation = `source-over`;
      let A = document.createElement(`canvas`);
      A.width = s.width, A.height = s.height;
      let j = A.getContext(`2d`);
      j.scale(E, E);
      let M = 0,
        N = () => {
          M += .016, m.current || (d.clearRect(0, 0, C, w), d.globalCompositeOperation = `source-over`, d.drawImage(D, 0, 0, C * E, w * E, 0, 0, C, w), d.globalCompositeOperation = `destination-out`, d.drawImage(A, 0, 0, C * E, w * E, 0, 0, C, w)), p.clearRect(0, 0, T.width, T.height);
          let e = !1;
          y.current.forEach(t => {
            if (t.alpha > 0) {
              if (e = !0, t.x += t.vx, t.y += t.vy, t.type === `falling`) {
                t.x += Math.sin(M * 5 + t.y * .01) * .5;
                let e = T.height * .2;
                t.y > e && (t.alpha -= .02)
              } else t.y -= .1, t.x += Math.sin(M + t.y) * .3, t.alpha -= t.decay;
              t.rotation += t.rotSpeed, p.save(), p.translate(t.x, t.y), p.rotate(t.rotation * Math.PI / 180), p.globalAlpha = Math.max(0, t.alpha), p.fillStyle = t.color, p.beginPath(), p.moveTo(-t.size, -t.size * .5), p.lineTo(t.size * .8, -t.size), p.lineTo(t.size, t.size * .8), p.lineTo(-t.size * .5, t.size), p.closePath(), p.fill(), p.restore()
            }
          }), !m.current || e ? b.current = requestAnimationFrame(N) : b.current = null
        };
      b.current = requestAnimationFrame(N);
      let P = e => {
          let t = s.getBoundingClientRect(),
            n = e.clientX,
            r = e.clientY;
          return e.touches && e.touches.length > 0 && (n = e.touches[0].clientX, r = e.touches[0].clientY), {
            x: n - t.left,
            y: r - t.top
          }
        },
        F = e => {
          if (m.current) return;
          h.current = !0;
          let t = P(e);
          g.current = t, R(t.x, t.y, t.x, t.y), u.current && (u.current.style.animation = `none`)
        },
        I = 0,
        L = e => {
          if (!h.current || m.current) return;
          let t = P(e),
            n = g.current || t;
          R(t.x, t.y, n.x, n.y), g.current = t, I++, I % 5 == 0 && z()
        },
        R = (e, t, n, r) => {
          let i = Math.min(C, w) * .1,
            a = j.createRadialGradient(e, t, 0, e, t, i);
          a.addColorStop(0, `rgba(0,0,0,1)`), a.addColorStop(.4, `rgba(0,0,0,0.8)`), a.addColorStop(.8, `rgba(0,0,0,0.2)`), a.addColorStop(1, `rgba(0,0,0,0)`), j.globalCompositeOperation = `source-over`, j.fillStyle = a, j.beginPath(), j.arc(e, t, i, 0, Math.PI * 2, !1), j.fill();
          let o = Math.hypot(e - n, t - r),
            s = i * .2;
          if (o > s) {
            let a = Math.floor(o / s);
            for (let o = 0; o < a; o++) {
              let s = n + (e - n) * (o / a),
                c = r + (t - r) * (o / a),
                l = j.createRadialGradient(s, c, 0, s, c, i);
              l.addColorStop(0, `rgba(0,0,0,1)`), l.addColorStop(.4, `rgba(0,0,0,0.8)`), l.addColorStop(.8, `rgba(0,0,0,0.2)`), l.addColorStop(1, `rgba(0,0,0,0)`), j.fillStyle = l, j.beginPath(), j.arc(s, c, i, 0, Math.PI * 2, !1), j.fill()
            }
          }
          let c = Math.max(1, Math.floor(o / (C / 10)));
          for (let i = 0; i <= c; i++) {
            let a = n + (e - n) * (i / c),
              o = r + (t - r) * (i / c),
              s = Math.floor(a / C * 10),
              l = Math.floor(o / w * 10);
            s >= 1 && s <= 8 && l >= 1 && l <= 8 && _.current.add(`${s},${l}`)
          }
          b.current ||= requestAnimationFrame(N)
        },
        z = () => {
          if (m.current) return;
          let e = _.current.size;
          e > 10 && !v.current && (v.current = !0, f(!0)), e > 16 && V()
        },
        B = () => {
          !h.current || m.current || (h.current = !1, g.current = null, z())
        },
        V = () => {
          if (!m.current) {
            m.current = !0, i.to(s, {
              opacity: 0,
              duration: 1.2,
              ease: `power2.inOut`
            }), l.current && i.to(l.current, {
              opacity: 0,
              duration: 1,
              ease: `power2.inOut`
            }), i.to(t.current.querySelectorAll(`.${o.revealItem}`), {
              opacity: 1,
              scale: 1,
              duration: 1.5,
              stagger: .2,
              ease: `elastic.out(1, 0.5)`
            });
            for (let e = 0; e < 800; e++) y.current.push(H(T.width, T.height));
            b.current ||= requestAnimationFrame(N)
          }
        },
        H = (e, t) => {
          let n = [`#D4AF37`, `#FDF2A9`, `#FFFFFF`];
          return {
            type: `falling`,
            x: Math.random() * e,
            y: -Math.random() * t,
            vx: (Math.random() - .5) * 8,
            vy: Math.random() * 5 + 3,
            size: Math.random() * 5 + 2,
            color: n[Math.floor(Math.random() * n.length)],
            alpha: Math.random() * .5 + .5,
            decay: 0,
            rotation: Math.random() * 360,
            rotSpeed: (Math.random() - .5) * 20
          }
        },
        U = (e, t, n, r) => {
          e.addEventListener(t, n, r), x.current.push({
            elem: e,
            type: t,
            handler: n,
            options: r
          })
        };
      return U(s, `invitation-reveal`, V), U(s, `mousedown`, F), U(s, `mousemove`, L), U(s, `mouseup`, B), U(s, `mouseleave`, B), U(s, `touchstart`, e => {
        S(e), F(e)
      }, {
        passive: !1
      }), U(s, `touchmove`, e => {
        S(e), L(e)
      }, {
        passive: !1
      }), U(s, `touchend`, B, {
        passive: !0
      }), U(s, `touchcancel`, B, {
        passive: !0
      }), () => {
        b.current && cancelAnimationFrame(b.current), x.current.forEach(({
          elem: e,
          type: t,
          handler: n,
          options: r
        }) => {
          e.removeEventListener(t, n, r)
        }), x.current = [], a.revert()
      }
    }, []), (0, s.jsxs)(`section`, {
      className: o.scratchSection,
      ref: e,
      children: [(0, s.jsxs)(`div`, {
        className: o.header,
        children: [(0, s.jsx)(`h4`, {
          className: o.headingSmall,
          children: W.scratchTitle
        }), (0, s.jsx)(`h2`, {
          className: o.headingSub,
          children: W.scratchSubtitle
        })]
      }), (0, s.jsxs)(`div`, {
        className: o.container,
        children: [(0, s.jsx)(`div`, {
          className: o.ambientDecor,
          children: p.map((e, t) => (0, s.jsx)(`div`, {
            className: o.ambientParticle,
            style: e
          }, t))
        }), (0, s.jsxs)(`div`, {
          className: o.card,
          ref: t,
          children: [(0, s.jsx)(`svg`, {
            width: `0`,
            height: `0`,
            style: {
              position: `absolute`
            },
            children: (0, s.jsx)(`defs`, {
              children: (0, s.jsx)(`clipPath`, {
                id: `heartClip`,
                clipPathUnits: `objectBoundingBox`,
                children: (0, s.jsx)(`path`, {
                  d: `M 0.5 0.889 C 0.256 0.692, 0.05 0.475, 0.05 0.282 C 0.05 0.136, 0.156 0.05, 0.29 0.05 C 0.378 0.05, 0.454 0.10, 0.5 0.172 C 0.546 0.10, 0.622 0.05, 0.71 0.05 C 0.844 0.05, 0.95 0.136, 0.95 0.282 C 0.95 0.475, 0.744 0.692, 0.5 0.889 Z`
                })
              })
            })
          }), (0, s.jsx)(`div`, {
            className: o.heartBackground,
            children: (0, s.jsx)(`svg`, {
              viewBox: `0 0 100 100`,
              className: o.heartSvg,
              preserveAspectRatio: `none`,
              children: (0, s.jsx)(`path`, {
                d: `M 50 88.9 C 25.6 69.2, 5 47.5, 5 28.2 C 5 13.6, 15.6 5, 29 5 C 37.8 5, 45.4 10, 50 17.2 C 54.6 10, 62.2 5, 71 5 C 84.4 5, 95 13.6, 95 28.2 C 95 47.5, 74.4 69.2, 50 88.9 Z`,
                fill: `#ffffff`
              })
            })
          }), (0, s.jsx)(`div`, {
            className: o.revealedContent,
            children: (0, s.jsx)(`div`, {
              className: o.revealItem,
              children: (0, s.jsxs)(`h2`, {
                className: o.dateText,
                children: [W.dateLabel]
              })
            })
          }), (0, s.jsxs)(`div`, {
            className: o.canvasWrapper,
            children: [d && (0, s.jsx)(`div`, {
              className: o.shimmerOverlay
            }), (0, s.jsx)(`svg`, {
              ref: u,
              viewBox: `0 0 100 100`,
              className: o.heartBorder,
              preserveAspectRatio: `none`,
              children: (0, s.jsx)(`path`, {
                d: `M 50 88.9 C 25.6 69.2, 5 47.5, 5 28.2 C 5 13.6, 15.6 5, 29 5 C 37.8 5, 45.4 10, 50 17.2 C 54.6 10, 62.2 5, 71 5 C 84.4 5, 95 13.6, 95 28.2 C 95 47.5, 74.4 69.2, 50 88.9 Z`,
                fill: `none`,
                stroke: `#D4AF37`,
                strokeWidth: `1.2`,
                strokeLinecap: `round`,
                strokeLinejoin: `round`
              })
            }), (0, s.jsx)(`canvas`, {
              ref: n,
              className: o.scratchCanvas
            })]
          }), (0, s.jsx)(`canvas`, {
            ref: r,
            className: o.particleCanvas
          })]
        }), (0, s.jsxs)(`div`, {
          className: o.instructionWrapper,
          ref: l,
          children: [(0, s.jsx)(`h3`, {
            className: o.instructionText,
            children: W.scratchHint
          }), (0, s.jsxs)(`svg`, {
            className: o.handIcon,
            viewBox: `0 0 24 24`,
            fill: `none`,
            stroke: `currentColor`,
            strokeWidth: `1.5`,
            strokeLinecap: `round`,
            strokeLinejoin: `round`,
            children: [(0, s.jsx)(`path`, {
              d: `M8 13v-8.5a1.5 1.5 0 0 1 3 0v7.5`
            }), (0, s.jsx)(`path`, {
              d: `M11 11.5v-2a1.5 1.5 0 0 1 3 0v2.5`
            }), (0, s.jsx)(`path`, {
              d: `M14 10.5v-1.5a1.5 1.5 0 0 1 3 0v2.5`
            }), (0, s.jsx)(`path`, {
              d: `M17 11.5a1.5 1.5 0 0 1 3 0v4.5a6 6 0 0 1 -6 6h-2h.208a6 6 0 0 1 -5.012 -2.7a69.74 69.74 0 0 1 -.196 -.3c-.312 -.479 -1.407 -2.388 -3.286 -5.728a1.5 1.5 0 0 1 .536 -2.022a1.867 1.867 0 0 1 2.28 .28l1.47 1.47`
            })]
          })]
        })]
      })]
    })
  };
export {
  l as
  default
};
