import {
  invitation as W
} from "../src/settings.js";
import {
  n as e
} from "./rolldown-runtime-Bh1tDfsg.js";
import {
  c as t,
  n,
  o as r,
  t as i
} from "./react-CC4f5wG5.js";
import {
  n as a,
  r as o,
  t as s
} from "./gsap-BL2wBkID.js";
var c = e(t(), 1),
  l = {
    button: `_button_1m5kk_1`,
    icon: `_icon_1m5kk_25`
  },
  u = r();

function d({
  query: e,
  url: t,
  label: n = `View on Maps`
}) {
  return (0, u.jsxs)(`a`, {
    href: t || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(e)}`,
    target: `_blank`,
    rel: `noopener noreferrer`,
    className: l.button,
    children: [(0, u.jsxs)(`svg`, {
      className: l.icon,
      viewBox: `0 0 24 24`,
      fill: `none`,
      stroke: `currentColor`,
      strokeWidth: `1.5`,
      "aria-hidden": `true`,
      children: [(0, u.jsx)(`path`, {
        d: `M12 21s7-4.5 7-11a7 7 0 1 0-14 0c0 6.5 7 11 7 11z`
      }), (0, u.jsx)(`circle`, {
        cx: `12`,
        cy: `10`,
        r: `2.5`
      })]
    }), n]
  })
}
var f = {},
  p = {
    timelineSection: `_timelineSection_4071w_2`,
    title: `_title_4071w_10`,
    timelineContainer: `_timelineContainer_4071w_19`,
    cardWrapper: `_cardWrapper_4071w_28`,
    card: `_card_4071w_28`,
    cardHeader: `_cardHeader_4071w_44`,
    eventTitle: `_eventTitle_4071w_51`,
    date: `_date_4071w_59`,
    time: `_time_4071w_2`,
    imageWrapper: `_imageWrapper_4071w_77`,
    eventImage: `_eventImage_4071w_83`,
    cardFooter: `_cardFooter_4071w_92`,
    venueSection: `_venueSection_4071w_99`,
    venueNameWrapper: `_venueNameWrapper_4071w_109`,
    venueLabel: `_venueLabel_4071w_116`,
    venueName: `_venueName_4071w_109`,
    venueStreet: `_venueStreet_4071w_141`,
    venueCountry: `_venueCountry_4071w_149`,
    mapWrap: `_mapWrap_4071w_160`,
    journeySection: `_journeySection_4071w_165`,
    mapContainer: `_mapContainer_4071w_176`,
    canadaContainer: `_canadaContainer_4071w_184`,
    indiaContainer: `_indiaContainer_4071w_184`,
    buildingIcon: `_buildingIcon_4071w_195`,
    buildingIconIndia: `_buildingIconIndia_4071w_195`,
    locationTextContainer: `_locationTextContainer_4071w_202`,
    locationTitle: `_locationTitle_4071w_209`,
    pinIcon: `_pinIcon_4071w_221`,
    flightTrack: `_flightTrack_4071w_225`,
    dashedLine: `_dashedLine_4071w_232`,
    airplaneWrapper: `_airplaneWrapper_4071w_243`,
    planeIcon: `_planeIcon_4071w_252`,
    planeShadow: `_planeShadow_4071w_262`
  };
o.registerPlugin(a, s);
var g = W.events,
  _ = (0, c.memo)(({
    src: e
  }) => {
    let {
      ref: t,
      inView: r
    } = n({
      threshold: .1,
      triggerOnce: !1
    }), i = (0, c.useRef)(null);
    return (0, c.useEffect)(() => {
      i.current && (r ? i.current.play().catch(e => console.log(`Autoplay prevented:`, e)) : i.current.pause())
    }, [r]), (0, u.jsx)(`div`, {
      className: p.imageWrapper,
      ref: t,
      children: (0, u.jsx)(`video`, {
        ref: i,
        src: e,
        className: p.eventImage,
        muted: !0,
        loop: !0,
        playsInline: !0,
        preload: `metadata`,
        style: {
          objectFit: `cover`
        }
      })
    })
  }),
  v = (0, c.memo)(({
    src: e,
    alt: t,
    isFirst: n
  }) => (0, u.jsx)(`div`, {
    className: p.imageWrapper,
    children: (0, u.jsx)(`img`, {
      src: e,
      alt: t,
      className: p.eventImage,
      loading: n ? `eager` : `lazy`,
      decoding: `async`,
      width: `600`,
      height: `400`
    })
  })),
  y = (0, c.memo)(({
    event: e,
    isFirst: t
  }) => e.video ? (0, u.jsx)(_, {
    src: e.video
  }) : (0, u.jsx)(v, {
    src: e.image,
    alt: e.title,
    isFirst: t
  })),
  b = (0, c.memo)(({
    event: e,
    isFirst: t
  }) => {
    let n = e.address,
      r = ``;
    return (0, u.jsx)(`div`, {
      className: p.cardWrapper,
      children: (0, u.jsxs)(`div`, {
        className: p.card,
        children: [(0, u.jsxs)(`div`, {
          className: p.cardHeader,
          children: [(0, u.jsx)(`h3`, {
            className: p.eventTitle,
            children: e.title
          }), (0, u.jsx)(`p`, {
            className: e.featured ? `${p.date} wedding-date` : p.date,
            children: e.date
          }), (0, u.jsx)(`p`, {
            className: e.featured ? `${p.time} wedding-timing` : p.time,
            children: e.time
          }), e.note && (0, u.jsx)(`p`, {
            className: `dinner-note`,
            children: e.note
          })]
        }), (0, u.jsx)(y, {
          event: e,
          isFirst: t
        }), (0, u.jsx)(`div`, {
          className: p.cardFooter,
          children: (0, u.jsxs)(`div`, {
            className: p.venueSection,
            children: [(0, u.jsxs)(`div`, {
              className: p.venueNameWrapper,
              children: [(0, u.jsx)(`p`, {
                className: p.venueLabel,
                children: `VENUE`
              }), (0, u.jsx)(`p`, {
                className: p.venueName,
                children: e.venue
              })]
            }), (0, u.jsx)(`p`, {
              className: p.venueStreet,
              children: n
            }), (0, u.jsx)(`p`, {
              className: p.venueCountry,
              children: r
            }), (0, u.jsx)(`div`, {
              className: p.mapWrap,
              children: (0, u.jsx)(d, {
                query: e.query,
                url: e.url,
                label: `VIEW ON MAPS`
              })
            })]
          })
        })]
      })
    })
  }),
  x = (0, c.memo)(() => {
    let e = (0, c.useRef)(null),
      t = (0, c.useRef)(null),
      n = (0, c.useRef)(null),
      r = (0, c.useRef)(null),
      s = (0, c.useRef)(null),
      l = (0, c.useRef)(null),
      d = (0, c.useRef)(null),
      f = (0, c.useRef)(null);
    return (0, c.useEffect)(() => {
      let i = o.context(() => {
          if (o.utils.toArray(`.${p.card}`).forEach(e => {
              o.fromTo(e, {
                opacity: 0,
                y: 50
              }, {
                opacity: 1,
                y: 0,
                duration: .8,
                ease: `power2.out`,
                scrollTrigger: {
                  trigger: e,
                  start: `top 85%`
                }
              })
            }), t.current && n.current && r.current) {
            o.set(t.current, {
              opacity: 1,
              xPercent: -50,
              yPercent: -50,
              rotation: 180,
              x: 0,
              y: 0
            }), o.set(d.current, {
              opacity: .5,
              scale: 1,
              y: -5
            }), o.to(f.current, {
              y: -2,
              duration: .8,
              repeat: -1,
              yoyo: !0,
              ease: `sine.inOut`
            });
            let e = o.timeline({
                scrollTrigger: {
                  trigger: r.current,
                  start: `top 35%`,
                  end: `bottom 85%`,
                  scrub: 1,
                  onUpdate: e => {
                    if (t.current) {
                      let n = e.direction === 1 ? 180 : 0;
                      o.to(t.current, {
                        rotation: n,
                        duration: .5,
                        ease: `power2.out`,
                        overwrite: `auto`
                      })
                    }
                  }
                }
              }),
              i = n.current?.offsetHeight || 350;
            e.to(t.current, {
              y: i,
              duration: .8,
              ease: `none`
            }, .1), e.to(f.current, {
              scale: 1.08,
              duration: .4,
              ease: `sine.inOut`
            }, .1).to(f.current, {
              scale: 1,
              duration: .4,
              ease: `sine.inOut`
            }, .5), e.to(d.current, {
              scale: .6,
              opacity: .15,
              y: -15,
              duration: .4,
              ease: `sine.inOut`
            }, .1).to(d.current, {
              scale: 1,
              opacity: .5,
              y: -5,
              duration: .4,
              ease: `sine.inOut`
            }, .5), e.to(s.current, {
              scale: 1.05,
              filter: `drop-shadow(0 15px 30px rgba(201, 162, 39, 0.4))`,
              duration: .1,
              ease: `power2.out`
            }, .9)
          }
        }, e),
        c = () => a.refresh(),
        l = e.current?.querySelectorAll(`img`) || [];
      l.forEach(e => {
        e.complete || e.addEventListener(`load`, c)
      });
      let u;
      return r.current && (u = new ResizeObserver(() => c()), u.observe(r.current), u.observe(e.current)), () => {
        i.revert(), l.forEach(e => e.removeEventListener(`load`, c)), u && u.disconnect()
      }
    }, []), (0, u.jsxs)(`section`, {
      className: p.timelineSection,
      ref: e,
      children: [(0, u.jsx)(`h2`, {
        className: p.title,
        children: W.eventsTitle
      }), (0, u.jsxs)(`div`, {
        className: p.timelineContainer,
        children: [g.slice(0, 3).map((e, t) => (0, u.jsx)(b, {
          event: e,
          isFirst: t === 0
        }, `ev1-${t}`)), g.slice(3).map((e, t) => (0, u.jsx)(b, {
          event: e
        }, `ev2-${t}`))]
      })]
    })
  });
export {
  x as
  default
};
