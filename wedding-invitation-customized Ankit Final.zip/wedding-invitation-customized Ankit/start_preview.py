"""Double-click with Python 3 to open your invitation editor. No packages required."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Timer
import webbrowser

if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    handler = partial(SimpleHTTPRequestHandler, directory=str(root))
    try:
        server = ThreadingHTTPServer(('127.0.0.1', 8765), handler)
    except OSError:
        server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    port = server.server_address[1]
    url = f'http://127.0.0.1:{port}/editor.html'
    print(f'Editor: {url}\nInvitation: http://127.0.0.1:{port}/\nKeep this window open. Press Ctrl+C to stop.')
    Timer(.7, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
