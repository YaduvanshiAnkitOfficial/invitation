# Attribution and permissions

The invitation design, original public web application, photographs, event illustrations, ribbon/palace video, music and monogram were delivered by the reference website at https://anushamukul.creativeconceptsgifts.in. Its original footer credit, "Creative Concept Invites", is retained in the sample configuration. Retrieval and inclusion do not establish a licence for public redistribution or create ownership rights. The original authors, photographers, artists, performers and other rights holders retain their rights. Replace assets with your own or obtain suitable permission before public reuse. The supplied music filename is `mangalayam-saathiya.mp3`; no music licence is represented as granted.

The package contains production runtime libraries identified by the reference application, including React / React DOM, GSAP and Lenis. Their original copyright and licence notices within the delivered vendor bundles remain intact. Their applicable upstream terms continue to apply. No blanket open-source licence is asserted for this combined invitation package.

Fonts included from the reference and Google Fonts: Mussica Swash, Cinzel, Cormorant Garamond, Parisienne and Great Vibes. Font names identify their respective creators' work. The reference's Mussica font licence has not been supplied by its owner. Retain relevant notices and confirm permissions for your intended distribution. Official font information: https://fonts.google.com/ .

New configuration, editor and preview tooling were written for this adaptation. These additions do not change the rights attached to the reference site, its assets or its libraries.
