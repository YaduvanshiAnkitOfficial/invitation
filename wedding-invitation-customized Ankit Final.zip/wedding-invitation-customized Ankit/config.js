// Your editable wedding invitation settings.
window.INVITATION = {
  "bride": "Ankit",
  "groom": "Sakshi",
  "brideRelation": "Son of",
  "groomRelation": "Daughter of",
  "brideParents": "Smt. Savita & Sh. Rajendra Prasad Yadav",
  "groomParents": "Smt. Jyoti & Sh. Vijay Kumar",
  "dateTime": "2026-11-21T17:00:00+05:30",
  "displayTimeZone": "Asia/Kolkata",
  "prayer": "॥ श्री गणेशाय नमः ॥",
  "prayerLines": [
    "विघ्न हरण मंगल करण, गणनायक गणराज।",
    "प्रथम निमंत्रण आपको, सकल सुधारो काज॥"
  ],
  "inviteTitle": "We Cordially Invite You",
  "invitationLines": [
    "Together with our beloved family,",
    "we request the honour of your gracious",
    "presence to celebrate the wedding of"
  ],
  "loadingText": "✨ A Beautiful Love Story Awaits... ✨",
  "tapText": "Tap to Begin",
  "withText": "With",
  "wedsText": "Weds",
  "scrollText": "Scroll Down",
  "scratchTitle": "A Special Surprise",
  "scratchSubtitle": "Scratch the heart to reveal our wedding date",
  "scratchHint": "Scratch to reveal! ✨",
  "dateLabel": "Saturday, 21 November, 2026",
  "countdownTitle": "The Big Day Approaches",
  "storyTitle": "Together, Forever",
  "storyParagraphs": [
    "A new chapter, a lifetime of memories, and a celebration made special by you.",
    "With the love and blessings of our families, we invite you to share in the joy of our wedding.",
    "As we begin this beautiful new chapter, we look forward to a lifetime of love, laughter, and memories together.",
    "We can’t wait to celebrate our forever with the people who mean the most to us!"
  ],
  "gallery": [
    "media/upload-001.png"
  ],
  "eventsTitle": "Wedding Events",
  "events": [
    {
      "title": "Haldi",
      "date": "19 NOVEMBER 2026",
      "time": "THURSDAY • 4:00 PM",
      "image": "media/event-haldi.webp",
      "venue": "Our Residence — Ghaziabad",
      "address": "",
      "url": "https://maps.app.goo.gl/xJZbLuAynqEAbzeYA",
      "note": "",
      "featured": false
    },
    {
      "title": "Mehandi",
      "date": "20 NOVEMBER 2026",
      "time": "FRIDAY • 4:00 PM",
      "image": "media/event-mehndi.webp",
      "venue": "Our Residence — Ghaziabad",
      "address": "",
      "url": "https://maps.app.goo.gl/xJZbLuAynqEAbzeYA",
      "note": "",
      "featured": false
    },
    {
      "title": "Sangeet Ceremony",
      "date": "20 NOVEMBER 2026",
      "time": "FRIDAY • 6:00 PM",
      "image": "media/event-sangeet.webp",
      "venue": "Our Residence — Ghaziabad",
      "address": "",
      "url": "https://maps.app.goo.gl/xJZbLuAynqEAbzeYA",
      "note": ""
    },
    {
      "title": "Wedding",
      "date": "21 November 2026, Saturday",
      "time": "Arrival of Baraat : 7:00PM\nDinner : 8:00PM",
      "image": "media/event-wedding.webp",
      "venue": "The Florence Banquet",
      "address": "Hall 26, Shivaji Marg, Najafgarh Road, Moti Nagar, Karam Pura, Industrial Area, New Delhi-110015",
      "url": "https://maps.app.goo.gl/enYTYn7PkXCHMuQF8",
      "note": "",
      "featured": true
    }
  ],
  "familyTitle": "With Blessings From",
  "family": [
    {
      "label": "Grand Parents",
      "names": "Late Smt. Kesari Devi & Late Sh. Brahmdev Yadav",
      "highlight": false
    },
    {
      "label": "Chacha Ji",
      "names": "Anmol Yadav, Dr. Nagendra Yadav, ",
      "highlight": false
    },
    {
      "label": "Brothers",
      "names": "Ram Pratap Yadav, Shiv Pratap Yadav, Anshuraj Yadav, Ashutosh Yadav, Amit Yadav, Manish Kumar Yadav",
      "highlight": false
    },
    {
      "label": "Sister",
      "names": "Anjali Yadav",
      "highlight": false
    },
    {
      "label": "Our Beloved Nephews & Nieces",
      "names": "Satyam, Shivam, Aashi, Chiku",
      "highlight": true
    }
  ],
  "familyQuote": "“Na Koi Phone, Na Koi Bahana, Humare Chachu ki Shaadi mein Jarur-Jarur Aana”",
  "thankYou": "Thank You",
  "credit": "",
  "media": {
    "poster": "media/6dc1c91f845cadaa.webp",
    "heroVideo": "videos/hero.mp4",
    "music": "media/mangalayam-saathiya.mp3",
    "record": "media/6d5b33044d1ae859.png",
    "monogram": "",
    "initials": "AS"
  },
  "theme": {
    "primary": "#6e1f2f",
    "background": "#faf5eb",
    "accent": "#c9a227",
    "text": "#2f2f2f"
  },
  "sharing": {
    "title": "Ankit Weds Sakshi",
    "description": "💍 Tap to open the invitation and celebrate our special day with us.",
    "image": "media/couple-1.jpg",
    "publicUrl": ""
  }
};
