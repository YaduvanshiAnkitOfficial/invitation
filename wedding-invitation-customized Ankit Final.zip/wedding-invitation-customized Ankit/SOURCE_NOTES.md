# Source notes

Reference: https://anushamukul.creativeconceptsgifts.in
Inspected and adapted: 24 October 2026.

The reference's publicly served HTML, JavaScript modules, styles, local name font, images, video and audio were retrieved to preserve its appearance and interactions. This is not a claim to possession of the original private repository, original JSX/TypeScript source or original asset production files.

Application changes:

- Added `config.js`, a central configuration adapter and a separate visual editor.
- Replaced fixed names, relation labels, prayer text, copy, story, gallery, date, event and family information with configuration references.
- Added editable monogram initials while retaining the floral SVG appearance.
- Removed fixed wedding date and time overrides in event cards.
- Fixed the countdown's zero transition.
- Added keyboard opening and date reveal, plus music state labels.
- Rewrote the family component as a readable data-driven component, preserving the original styles.
- Converted site resources to relative paths and saved the Google Fonts locally.
- Removed the unused original RSVP module. There are no submission endpoints in this package.
- Formatted editable application modules. Vendor bundles remain their distributed production builds.
- Added a complete in-browser ZIP exporter with CRC-32 and local uploaded media.

The generated floral monogram changes through the configuration. A monogram or text embedded in an image/video file does not change automatically. Sample sharing metadata is retained in the initial `index.html`; editor ZIP export rewrites it for the customized invitation. Direct `config.js` edits change the rendered page, while crawler previews also require editing the metadata in `index.html`.

Browser checks and packaging checks are recorded in `VERIFICATION.md`.
